def divide_by_three(num):
    "Doc"
    __version__ = "0.1"
	return num / 3